package it.uniroma3.siw.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
public class Movie {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(length = 500)
	private String picture;
	
	@NotBlank
	private String title;
	
	@NotNull
	@Min(1900)
	@Max(2023)
	private Integer year;
	
	@ManyToOne
	private Artist direttore;
	
	@ManyToMany(mappedBy = "filmsPerAttore")
	private List<Artist> attori;
	
	@OneToMany(mappedBy = "filmPerRecensione")//, fetch = FetchType.EAGER)
	//voglio che vengano caricate tutte le recensioni insieme al film
	private List<Recensione> recensioniPerFilm;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public Artist getDirettore() {
		return direttore;
	}
	public void setDirettore(Artist direttore) {
		this.direttore = direttore;
	}
	public List<Artist> getAttori() {
		return attori;
	}
	public void setAttori(List<Artist> attori) {
		this.attori = attori;
	}
	
	public List<Recensione> getRecensioniPerFilm() {
		return recensioniPerFilm;
	}
	public void setRecensioniPerFilm(List<Recensione> recensioniPerFilm) {
		this.recensioniPerFilm = recensioniPerFilm;
	}
	@Override
	public boolean equals(Object o) {
		Movie that = (Movie) o;
		return this.getTitle() == that.getTitle() && this.getYear() == that.getYear();
	}
	
	@Override
	public int hashCode() {
		return (int) this.getId();
	}
}