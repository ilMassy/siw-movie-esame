package it.uniroma3.siw.controller;

import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import it.uniroma3.siw.controller.validator.MovieValidator;
import it.uniroma3.siw.model.Artist;
import it.uniroma3.siw.model.Movie;
import it.uniroma3.siw.service.ArtistService;
import it.uniroma3.siw.service.MovieService;

@Controller
public class MovieController {
	
	@Autowired MovieService movieService;
	@Autowired MovieValidator movieValidator;
	@Autowired ArtistService artistService;


	@GetMapping("/index")
	public String index() {
		return "index.html";
	}
	
	@GetMapping("/admin/indexAdmin")
	public String indexAdmin() {
		return "admin/indexAdmin.html";
	}

	@GetMapping("/admin/indexMovie")
	public String indexMovie() {
		return "admin/indexMovie.html";
	}

	@GetMapping("/admin/formNewMovie")
	public String formNewMovie(Model model) {
		model.addAttribute("movie", new Movie());
		return "admin/formNewMovie.html";
	}

	@PostMapping("/admin/movies")
	public String newMovie(@Valid @ModelAttribute("movie") Movie movie, 
			@RequestParam("file") MultipartFile file, 
            BindingResult bindingResult, Model model) throws IOException {
		
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
	    
		movie.setPicture(fileName);
		this.movieValidator.validate(movie, bindingResult);
	    if (!bindingResult.hasErrors()) {
	      this.movieService.updateMovie(movie);
	      model.addAttribute("movie", movie);
	      return "movie.html";
	    } else {
	      return "admin/formNewMovie.html";
	    }

	}

	@GetMapping("/movies/{id}")
	public String getMovie(@PathVariable("id") Long id, Model model) {
		Movie movie = this.movieService.searchById(id).get();
		model.addAttribute("movie", movie);
		model.addAttribute("regista", movie.getDirettore());
		return "movie.html";
	}

	@GetMapping("/movies")
	public String showMovies(Model model) {
		model.addAttribute("movies", this.movieService.searchAll());
		return "movies.html";
	}

	//esercizio 28/03/2023
	@GetMapping("/admin/manageMovies")
	public String manageMovies(Model model) {
		model.addAttribute("movies", this.movieService.searchAll());
		return "admin/manageMovies.html";
	}

	@GetMapping("/admin/formSearchMovies")
	public String formSearchMovies() {
		return "admin/formSearchMovies.html";
	}

	@PostMapping("/searchMovies")
	public String searchMovies(Model model, @RequestParam Integer year) {
		model.addAttribute("movies", this.movieService.searchByYear(year));
		return "foundMovies.html";
	}

	//esercizio 28/03/2023
	@GetMapping("/admin/formUpdateMovie/{id}")
	public String formUpdateMovies(@PathVariable("id") Long id, Model model) {
		model.addAttribute("movie", this.movieService.searchById(id).get());
		model.addAttribute("director", this.movieService.searchById(id).get().getDirettore());
		return "admin/formUpdateMovie.html";
	}

	//esercizio 29/03/2023
	@GetMapping("/admin/addDirectorToMovie/{id}")
	public String addDirectorToMovie(@PathVariable("id") Long id, Model model) {
		model.addAttribute("movie", this.movieService.searchById(id).get());
		model.addAttribute("directors", this.artistService.searchAll());
		return "admin/directorsToAdd.html";
	}

	//esercizio 29/03/2023
	@GetMapping("/admin/setDirectorToMovie/{id1}/{id2}")
	public String setDirectorToMovie(@PathVariable("id1") Long id1, @PathVariable("id2") Long id2, Model model) {
		Movie movie = this.movieService.setDirectorToMovie(id1, id2);
		model.addAttribute("movie", movie);
		model.addAttribute("director", movie.getDirettore());
		return "admin/formUpdateMovie.html";
	}

	//esercizio 30/03/2023
	@GetMapping("/admin/updateActors/{id}")
	public String updateActors(@PathVariable("id") Long id, Model model) {
		Movie movieSet = this.movieService.searchById(id).get();
		List<Artist> attoriFilm = movieSet.getAttori();
		
		List<Artist> attoriNonFilm = this.artistService.searchAttoriNoFilmParametro(movieSet);
		model.addAttribute("movie", movieSet);
		model.addAttribute("attoriFilm", attoriFilm);
		model.addAttribute("attoriNonFilm", attoriNonFilm);

		return "admin/updateActors.html";
	}

	//esercizio 30/03/2023
	@GetMapping("/admin/deleteActor/{idActor}/{idMovie}")
	public String deleteActors(@PathVariable("idActor") Long idActor,@PathVariable("idMovie") Long idMovie, Model model) {
		Movie movie = this.movieService.deleteActorToMovie(idMovie, idActor);
		
		List<Artist> attoriNonFilm = this.artistService.searchAttoriNoFilmParametro(movie);
		model.addAttribute("movie", movie);
		model.addAttribute("attoriFilm", movie.getAttori());
		model.addAttribute("attoriNonFilm", attoriNonFilm);
		
		return "admin/updateActors.html";
	}

	//esercizio 30/03/2023
	@GetMapping("/admin/addActorToMovie/{idActor}/{idMovie}")
	public String addActorToMovie(@PathVariable("idActor") Long idActor,@PathVariable("idMovie") Long idMovie, Model model) {
		Movie movie = this.movieService.addActorToMovie(idMovie, idActor);
		
		List<Artist> attoriNonFilm = this.artistService.searchAttoriNoFilmParametro(movie);
		model.addAttribute("movie", movie);
		model.addAttribute("attoriFilm", movie.getAttori());
		model.addAttribute("attoriNonFilm", attoriNonFilm);
		
		return "admin/updateActors.html";
	}
	
	@GetMapping("/admin/deleteMovie/{idMovie}")
	public String deleteMovie(@PathVariable("idMovie") Long idMovie, Model model) {
		this.movieService.cancellaMoviePerId(idMovie);
		model.addAttribute("movies", this.movieService.searchAll());
		return "admin/manageMovies.html";
	}

}