package it.uniroma3.siw.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Movie;
import it.uniroma3.siw.model.Recensione;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.service.CredentialsService;
import it.uniroma3.siw.service.MovieService;
import it.uniroma3.siw.service.RecensioneService;
import it.uniroma3.siw.service.UserService;

@Controller
public class RecensioneController {
	
	@Autowired RecensioneService recensioneService;
	@Autowired MovieService movieService;
	@Autowired UserService userService;
	@Autowired CredentialsService credentialsService;
	
	@GetMapping(value="/admin/indexRecensioni")
	public String indexRecensioni() {
		return "admin/indexRecensioni.html";
	}
	
	
	@GetMapping("/recensioni/{idMovie}")
	public String getRecensioniMovie(@PathVariable("idMovie") Long idMovie, Model model) {
		Movie movie = this.movieService.searchById(idMovie).get();
		List<Recensione> recensioniFilm = movie.getRecensioniPerFilm();
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			UserDetails userDetails = (UserDetails) principal;
			Credentials credenziali = this.credentialsService.getCredentials(userDetails.getUsername());
			model.addAttribute("recensioni", recensioniFilm);
			model.addAttribute("movie", movie);
			User utente = credenziali.getUser();
			List<Recensione> recensioniUtente = utente.getRecensioniUtente();
			Recensione recensioneUtente = this.recensioneService.searchRecensioniFilmAndUser(movie, utente);
			if(recensioneUtente != null)
				model.addAttribute("recensioneUtente", recensioniUtente);
			return "logged/recensioniMovie.html";
		}
		else {
			model.addAttribute("recensioni", recensioniFilm);
			model.addAttribute("movie", movie);
			return "recensioniMovie.html";
		}
	}
	
	@GetMapping("/admin/recensioni")
	public String getRecensioni(Model model) {
		model.addAttribute("recensioni", this.recensioneService.searchAll());
		return "admin/recensioni.html";
	}
	
	@GetMapping("/recensione/{idRecensione}")
	public String getRecensione(@PathVariable("idRecensione") Long idRecensione, Model model) {
		Recensione recensione = this.recensioneService.searchById(idRecensione).get();
		model.addAttribute("recensione", recensione);
		model.addAttribute("credenziali", recensione.getUtente().getCredenziali().getUsername());
		return "recensione.html";
	}
	
	@GetMapping("/logged/formNewRecensione/{idMovie}")
	public String formNewRecensione(@PathVariable("idMovie") Long idMovie, Model model) {
		model.addAttribute("recensione", new Recensione());
		model.addAttribute("movie", this.movieService.searchById(idMovie).get());
		return "logged/formNewRecensione.html";
	}
	
	@PostMapping("/logged/addRecensione/{idMovie}")
	public String addRecensione(@ModelAttribute("recensione") Recensione recensione,
			@PathVariable("idMovie") Long idMovie, Model model) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (this.recensioneService.saveRecensioneIfExists(recensione, this.movieService.searchById(idMovie).get(),
				userDetails.getUsername())) { 
			model.addAttribute("recensione", recensione);
			model.addAttribute("utente", userDetails.getUsername());
			model.addAttribute("credenziali", recensione.getUtente().getCredenziali().getUsername());
			return "recensione.html";
		} else {
			model.addAttribute("messaggioErrore", "Questa recensione esiste già");
			return "logged/formNewRecensione.html"; 
		}
	}
	
	@GetMapping("/admin/manageRecensioni")
	public String manageRecensioni(Model model) {
		model.addAttribute("recensioni", this.recensioneService.searchAll());
		return "admin/manageRecensioni.html";
	}
	
	@GetMapping("/admin/deleteRecensione/{idRecensione}")
	public String deleteidRecensione(@PathVariable("idRecensione") Long idRecensione, Model model) {
		this.recensioneService.cancellaRecensionePerId(idRecensione);
		
		model.addAttribute("recensioni", this.recensioneService.searchAll());
		
		return "admin/manageRecensioni.html";
	}

}
