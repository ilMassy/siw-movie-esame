package it.uniroma3.siw.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
public class Recensione {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@NotBlank
	private String title;
	
	@NotNull
	@Min(1)
	@Max(5)
	private Integer vote;
	
	@NotBlank
	private String text;
	
	@ManyToOne
	private Movie filmPerRecensione;  //utile quando voglio cancellare una recensione o vederle tutte
	
	@ManyToOne
	private User utente;     //per sapere di chi è la recensione

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getVote() {
		return vote;
	}

	public void setVote(Integer vote) {
		this.vote = vote;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	public Movie getFilmPerRecensione() {
		return filmPerRecensione;
	}

	public void setFilmPerRecensione(Movie filmPerRecensione) {
		this.filmPerRecensione = filmPerRecensione;
	}

	public User getUtente() {
		return utente;
	}

	public void setUtente(User utente) {
		this.utente = utente;
	}

	@Override
	public boolean equals(Object o) {
		Recensione that = (Recensione) o;
		return this.getTitle() == that.getTitle() && this.getVote() == that.getVote()
				&& this.getText() == that.getText();
	}
	
	@Override
	public int hashCode() {
		return (int) this.getId();
	}
	
}
