package it.uniroma3.siw.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Artist;
import it.uniroma3.siw.model.Movie;
import it.uniroma3.siw.model.Recensione;
import it.uniroma3.siw.repository.ArtistRepository;
import it.uniroma3.siw.repository.MovieRepository;

@Service
public class MovieService {
	
	@Autowired private MovieRepository movieRepository;
	@Autowired private ArtistRepository artistRepository;
	@Autowired private RecensioneService recensioneService;
	
	@Transactional
	public void updateMovie(Movie movie) {
		movieRepository.save(movie);
	}
	
	public  Optional<Movie> searchById(Long id) {
		return movieRepository.findById(id);
	}

	@Transactional
	public List<Movie> searchAll() {
		return (List<Movie>) movieRepository.findAll();
	}
	
	public List<Movie> searchByYear(Integer year) {
		return (List<Movie>) movieRepository.findByYear(year);
	}
	
	@Transactional
	public Movie setDirectorToMovie(Long id1, Long id2) {
		Movie movieSet = movieRepository.findById(id1).get();
		Artist directorSet = artistRepository.findById(id2).get();
		movieSet.setDirettore(directorSet);
		this.movieRepository.save(movieSet);
		return movieSet;
	}
	
	@Transactional
	public List<Artist> searchAttoriFilm(Long id1) {
		Movie movieSet = movieRepository.findById(id1).get();
		return  movieSet.getAttori();
	}
	
	@Transactional
	public Movie deleteActorToMovie(Long idMovie, Long idActor) {
		Movie movieSet = this.movieRepository.findById(idMovie).get();
		Artist attoreSet = this.artistRepository.findById(idActor).get();

		List<Artist> attoriFilm = movieSet.getAttori();
		attoriFilm.remove(attoreSet);
		attoreSet.getFilmsPerAttore().remove(movieSet);
		movieSet.setAttori(attoriFilm);

		this.movieRepository.save(movieSet);
		this.artistRepository.save(attoreSet);
		
		return movieSet;
	}
	
	@Transactional
	public Movie addActorToMovie(Long idMovie, Long idActor) {
		Movie movieSet = this.movieRepository.findById(idMovie).get();
		Artist attoreSet = this.artistRepository.findById(idActor).get();

		List<Artist> attoriFilm = movieSet.getAttori();
		attoriFilm.add(attoreSet);
		List<Movie> filmsPerAttore = attoreSet.getFilmsPerAttore();
		if(!filmsPerAttore.contains(movieSet))
			filmsPerAttore.add(movieSet);
		movieSet.setAttori(attoriFilm);

		this.movieRepository.save(movieSet);
		this.artistRepository.save(attoreSet);
		
		return movieSet;
	}
	
	@Transactional
	public void cancellaMoviePerId(Long id){
		Movie filmDaCancellare = this.movieRepository.findById(id).get();
		for(Recensione recensione:(filmDaCancellare.getRecensioniPerFilm())) {
			this.recensioneService.cancellaRecensionePerId(recensione.getId());
		}
		List<Artist> artistiFilm = this.artistRepository.findAllByfilmsPerAttore(filmDaCancellare);
		for(Artist artista:artistiFilm) {
			artista.getFilmsPerAttore().remove(filmDaCancellare);
			this.artistRepository.save(artista);
		}
		this.movieRepository.deleteById(id);
	}

}
