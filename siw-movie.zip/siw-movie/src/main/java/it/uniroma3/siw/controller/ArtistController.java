package it.uniroma3.siw.controller;


import java.io.IOException;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import it.uniroma3.siw.model.Artist;
import it.uniroma3.siw.model.Movie;
import it.uniroma3.siw.service.ArtistService;
import it.uniroma3.siw.service.MovieService;
import it.uniroma3.siw.utils.FileUploadUtil;

@Controller
public class ArtistController {
	
	@Autowired private ArtistService artistService;
	@Autowired private MovieService movieService;

	@GetMapping(value="/admin/formNewArtist")
	public String formNewArtist(Model model) {
		model.addAttribute("artist", new Artist());
		return "admin/formNewArtist.html";
	}
	
	@GetMapping(value="/admin/indexArtist")
	public String indexArtist() {
		return "admin/indexArtist.html";
	}
	
	@PostMapping("/admin/artist")
	public String newArtist(@ModelAttribute("artist") Artist artist, 
			@RequestParam("fileImage") MultipartFile multipartFile, Model model) throws IOException {
		
		if (this.artistService.saveArtistIfExists(artist)) { 
			
			String nomeFile = StringUtils.cleanPath(multipartFile.getOriginalFilename());
			artist.setPicture(nomeFile);
	    	
	    	this.artistService.updateArtist(artist);
	    	
	    	String uploadDir = "src/main/resources/static/images";
	    	
	    	FileUploadUtil.saveFile(uploadDir, nomeFile, multipartFile);
			model.addAttribute("artist", artist);
			return "artist.html";
		} else {
			model.addAttribute("messaggioErrore", "Questo artista non va bene");
			return "admin/formNewArtist.html"; 
		}
	}

	@GetMapping("/artist/{id}")
	public String getArtist(@PathVariable("id") Long id, Model model) {
		model.addAttribute("artist", this.artistService.searchById(id).get());
		return "artist.html";
	}

	@GetMapping("/artists")
	public String getArtists(Model model) {
		model.addAttribute("artists", this.artistService.searchAll());
		return "artists.html";
	}
	
	@GetMapping("/artistsMovie/{idMovie}")
	public String getArtistsMovie(@PathVariable("idMovie") Long idMovie, Model model) {
		Movie movie = this.movieService.searchById(idMovie).get();
		model.addAttribute("artists", movie.getAttori());
		return "artistsMovie.html";
	}
	
	@GetMapping("/admin/manageArtists")
	public String manageArtists(Model model) {
		model.addAttribute("artists", this.artistService.searchAll());
		return "admin/manageArtists.html";
	}
	
	@GetMapping("/admin/deleteArtist/{idArtist}")
	public String deleteidArtist(@PathVariable("idArtist") Long idArtist, Model model) {
		this.artistService.cancellaArtistPerId(idArtist);
		
		model.addAttribute("artists", this.artistService.searchAll());
		
		return "admin/manageArtists.html";
	}
}
