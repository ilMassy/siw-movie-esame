insert into movie values(nextval('hibernate_sequence'), 'full_Metal_Jacket.jpg', 'Full metal jacket', 1987);
insert into movie values(nextval('hibernate_sequence'), 'non_e_un_paese_per_vecchi.jpg', 'Non e'' un paese per vecchi', 2007);
insert into movie values(nextval('hibernate_sequence'), 'the_founder.jpg', 'The founder', 2016);
insert into movie values(nextval('hibernate_sequence'), 'harry_Potter_e_la_pietra_filosofale.jpg', 'Harry Potter e la pietra filosofale', 2001);

insert into artist values(nextval('hibernate_sequence'), '07/11/2001', null, 'Massimiliano', 'Italia', 'massimiliano_giangreco.jpg', 'Giangreco');
insert into artist values(nextval('hibernate_sequence'), '23/07/1989', null, 'Daniel', 'Regno Unito', 'Daniel_Radcliffe.png', 'Radcliffe');


