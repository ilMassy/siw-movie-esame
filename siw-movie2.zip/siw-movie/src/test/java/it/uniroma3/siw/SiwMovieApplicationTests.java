package it.uniroma3.siw;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiwMovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
