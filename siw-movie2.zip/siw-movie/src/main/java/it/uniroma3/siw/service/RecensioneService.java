package it.uniroma3.siw.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Movie;
import it.uniroma3.siw.model.Recensione;
import it.uniroma3.siw.model.User;
import it.uniroma3.siw.repository.MovieRepository;
import it.uniroma3.siw.repository.RecensioneRepository;
import it.uniroma3.siw.repository.UserRepository;

@Service
public class RecensioneService {

	@Autowired private RecensioneRepository recensioneRepository;
	@Autowired private MovieRepository movieRepository;
	@Autowired private UserRepository userRepository;
	@Autowired private CredentialsService credentialsService;

	@Transactional
	public void updateRecensione(Recensione recensione) {
		recensioneRepository.save(recensione);
	}

	@Transactional
	public  Optional<Recensione> searchById(Long id) {
		return recensioneRepository.findById(id);
	}

	@Transactional
	public List<Recensione> searchRecensioniFilm(Movie movie){
		return recensioneRepository.findAllByfilmPerRecensione(movie);
	}

	@Transactional
	public boolean saveRecensioneIfExists(Recensione recensione, Movie movie, String username){ 
		if (!recensioneRepository.existsByTitleAndVoteAndText(recensione.getTitle(),
				recensione.getVote(), recensione.getText())) {
			movie.getRecensioniPerFilm().add(recensione);
			movieRepository.save(movie);
			recensione.setFilmPerRecensione(movie);
			Credentials credenziali = credentialsService.getCredentials(username);
			User utente = credenziali.getUser();
			recensione.setUtente(utente);
			this.updateRecensione(recensione);
			utente.getRecensioniUtente().add(recensione);
			userRepository.save(utente); 
			return true;
		}
		return false;
	}

	@Transactional
	public List<Recensione> searchAll() {
		return (List<Recensione>) recensioneRepository.findAll();
	}

	@Transactional
	public void cancellaRecensionePerId(Long id){
		Recensione recensione = this.searchById(id).get();
		User utente = recensione.getUtente();
		utente.getRecensioniUtente().remove(recensione);
		userRepository.save(utente);
		this.recensioneRepository.deleteById(id);
	}
	
	@Transactional
	public Recensione searchRecensioniFilmAndUser(Movie movie, User utente){
		return recensioneRepository.findByFilmPerRecensioneAndUtente(movie, utente);
	}
}
