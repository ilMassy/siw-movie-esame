package it.uniroma3.siw.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Artist;
import it.uniroma3.siw.model.Movie;
import it.uniroma3.siw.repository.ArtistRepository;
import it.uniroma3.siw.repository.MovieRepository;

@Service
public class ArtistService {
	
	@Autowired private ArtistRepository artistRepository;
	@Autowired private MovieRepository movieRepository;
	
	public Optional<Artist> searchById(Long id) {
		return artistRepository.findById(id);
	}
	
	public List<Artist> searchAll() {
		return (List<Artist>) artistRepository.findAll();
	}
	
	public List<Artist> searchAttoriNoFilmParametro(Movie movieSet){
		return artistRepository.findAllByfilmsPerAttoreIsNotContaining(movieSet);
	}
	
	@Transactional
	public void updateArtist(Artist artist) {
		artistRepository.save(artist);
	}
	
	@Transactional
	public boolean saveArtistIfExists(Artist artist){ 
		if (!artistRepository.existsByNameAndSurname(artist.getName(), artist.getSurname())) {
			if(artist.getDateOfDeath() == null) { 
				this.updateArtist(artist);
				return true;
			}
			else if(artist.getDateOBirth().isBefore(artist.getDateOfDeath())) {
				this.updateArtist(artist);
				return true;
			}
		}
		return false;
	}
	
	@Transactional
	public void cancellaArtistPerId(Long id){
		Artist attore = this.searchById(id).get();
		List<Movie> movies = this.movieRepository.findAllByattori(attore);
		for(Movie movie : movies) {
			movie.getAttori().remove(attore);
			this.movieRepository.save(movie);
		}
		List<Movie> moviesDirettore = this.movieRepository.findAllBydirettore(attore);
		for(Movie movie : moviesDirettore) {
			movie.setDirettore(null);
			this.movieRepository.save(movie);
		}
		this.artistRepository.deleteById(id);
	}
}
