package it.uniroma3.siw.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import it.uniroma3.siw.model.Movie;
import it.uniroma3.siw.model.Recensione;
import it.uniroma3.siw.model.User;

public interface RecensioneRepository extends CrudRepository<Recensione, Long> {
	
	//per trovare tutte le recensioni di quel film
	public List<Recensione> findAllByfilmPerRecensione(Movie movie);
	
	public boolean existsByTitleAndVoteAndText(String title, Integer vote, String text);
	
	public Recensione findByFilmPerRecensioneAndUtente(Movie movie, User utente);
	
}
